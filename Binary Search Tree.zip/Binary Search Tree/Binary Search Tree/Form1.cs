﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace Binary_Search_Tree
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        bst treemahasiswa = new bst();

        private void Form1_Load(object sender, EventArgs e)
        {



            treemahasiswa.insert(10);
            treemahasiswa.insert(7);
            treemahasiswa.insert(16);
            treemahasiswa.insert(11);
            treemahasiswa.insert(13);
            treemahasiswa.insert(8);
            treemahasiswa.insert(4);
            treemahasiswa.insert(3);
            treemahasiswa.insert(6);
            treemahasiswa.insert(5);

            int a = 10;


            List<Node> temp = treemahasiswa.traverseBFS();

            foreach (Node node in temp)
            {
                listBox1.Items.Add(node.value);
            }

            temp = treemahasiswa.traverseDFS();
            foreach (Node node in temp)
            {
                listBox2.Items.Add(node.value);
            }

            Node tempnode = treemahasiswa.getNode(11);

            if (tempnode != null)
            {
                listBox3.Items.Add(tempnode.value);
                if (tempnode.left != null)
                {
                    listBox3.Items.Add(tempnode.left.value);
                }

                if (tempnode.right != null)
                {
                    listBox3.Items.Add(tempnode.right.value);
                }
            }
            

        }

        private void listBox4_SelectedIndexChanged(object sender, EventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {
            treemahasiswa.delete(Convert.ToInt32( textBox1.Text));

            listBox1.Items.Clear();
            List<Node> temp = treemahasiswa.traverseBFS();

            foreach (Node node in temp)
            {
                listBox1.Items.Add(node.value);
            }

        }
    }
}
