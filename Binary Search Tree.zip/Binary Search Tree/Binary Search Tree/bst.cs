﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Binary_Search_Tree
{

    class Node
    {
        public int value { get; set; }
        public Node left { get; set; }
        public Node right { get; set; }


        public Node(int v=5, Node anakkiri = null, Node anakkanan = null)
        {
            value = v;
            left = anakkiri;
            right = anakkanan;
        }




    }

    class bst
    {
        public Node root;

        public bst()
        {
            root = null;
        }

        
        public void insert(int valuebaru){

            Node baru = new Node(valuebaru);

            if (root == null)
            {
                root = baru;
            }
            else
            {
                Node temp = root;

                while (temp != null)
                {
                    if (temp.value > baru.value)
                    {
                        if (temp.left == null)
                        {
                            temp.left = baru;
                            temp = null;
                        }
                        else
                        {
                            temp = temp.left;
                        }
                    }
                    else
                    {

                        if (temp.right == null)
                        {
                            temp.right = baru;
                            temp = null;
                        }
                        else
                        {
                            temp = temp.right;
                        }
                    }
                }
            }
        
        }

        public Node getPredecesor(Node cari)
        {



            return null;

        }
        



        public List<Node> traverseBFS(){
            
            List<Node> isibst=new List<Node>();
            Queue<Node> explore = new Queue<Node>();

            Node temp=root;

            if (temp != null)
            {
                explore.Enqueue(temp);
            }
            while (explore.Count > 0)
            {
                temp = explore.Dequeue();

                isibst.Add(temp);
                if (temp.left != null)
                    explore.Enqueue(temp.left);

                if (temp.right != null)
                    explore.Enqueue(temp.right);
            }

            


            return isibst;
        }


        public Node getNode(int value)
        {

            Node temp = root;

            while (temp != null)
            {
                if (temp.value == value)
                {
                    return temp;
                }
                else if (temp.value > value)
                {
                    temp = temp.left;
                }
                else
                {
                    temp = temp.right;
                }
            }

            return null;
        }

        public Node getParentNode(int value)
        {
            Node temp = root;

            while (temp != null)
            {
                if (temp.left!=null && temp.left.value == value)
                {
                    return temp;
                }
                else if (temp.right != null && temp.right.value == value)
                {
                    return temp;
                }

                
                if (temp.value >= value)
                {
                    temp=temp.left;
                }
                
                else
                {
                    temp = temp.right;
                }
            }


            return null;
        }

        
        public void delete(int value)
        {
            Node parent = getParentNode(value);
            Node del_node;
            
            //hapus root, node tidak punya parent
            if (parent == null)
            {
                del_node = root;
                //del_node = temp.left;
                //delete opsi 1
                if (del_node.left == null && del_node.right == null)
                {
                    root = null;
                }
                //if del_node had one child, point the pointer parent to a child of del_node
                else if (del_node.left != null && del_node.right == null)
                {
                    root = del_node.left;
                }
                else if (del_node.left == null && del_node.right != null)
                {
                    root = del_node.right;
                }
                //delete node yang punya anak kanan dan kiri 
                //cari predecesor nya dulu.
                else
                {
                    Node predecesor = del_node.left;
                    int valuepredecesor;
                    if (predecesor.right != null)
                    {
                        while (predecesor.right.right != null)
                        {
                            predecesor = predecesor.right;
                        }
                        valuepredecesor = predecesor.right.value;
                    
                    }
                    else
                    {
                        valuepredecesor = predecesor.value;
                    }
                    delete(valuepredecesor);
                    del_node.value = valuepredecesor;


                }

            
            }

            //anak kiri yang di hapus
            else if (parent.left.value == value)
            {
                del_node = parent.left;
                //delete opsi 1
                if (del_node.left == null && del_node.right == null)
                {
                    parent.left = null;
                }
                //if del_node had one child, point the pointer parent to a child of del_node
                else if (del_node.left != null && del_node.right == null)
                {
                    parent.left = del_node.left;
                }
                else if (del_node.left == null && del_node.right != null)
                {
                    parent.left = del_node.right;
                }
                    //delete node yang punya anak kanan dan kiri 
                    //cari predecesor nya dulu.
                else
                {
                    Node predecesor = del_node.left;
                    int valuepredecesor;

                    if (predecesor.right != null)
                    {
                        while (predecesor.right.right != null)
                        {
                            predecesor = predecesor.right;
                        }
                        valuepredecesor = predecesor.right.value;

                    }
                    else
                    {
                        valuepredecesor = predecesor.value;
                    }
                    delete(valuepredecesor);
                    del_node.value = valuepredecesor;


                }

            }
            // anak kanan yang di hapus
            else
            {
                del_node = parent.right;
                //delete opsi 1
                if (del_node.left == null && del_node.right == null)
                {
                    parent.right = null;
                }
                //if del_node had one child, point the pointer parent to a child of del_node
                else if (del_node.left != null && del_node.right == null)
                {
                    parent.right = del_node.left;
                }
                else if (del_node.left == null && del_node.right != null)
                {
                    parent.right = del_node.right;
                }
                //delete node yang punya anak kanan dan kiri 
                //cari predecesor nya dulu.
                else
                {
                    Node predecesor = del_node.left;
                    int valuepredecesor;
                    if (predecesor.right != null)
                    {
                        while (predecesor.right.right != null)
                        {
                            predecesor = predecesor.right;
                        }
                        valuepredecesor = predecesor.right.value;

                    }
                    else
                    {
                        valuepredecesor = predecesor.value;
                    }
                    delete(valuepredecesor);
                    del_node.value = valuepredecesor;


                }
            }




        }

        public List<Node> traverseDFS()
        {

            List<Node> isibst = new List<Node>();

            Node temp = root;


            Stack<Node> explore = new Stack<Node>();
            explore.Push(temp);
            while (explore.Count > 0)
            {
                temp = explore.Pop();
                isibst.Add(temp);

                if(temp.right!=null)
                    explore.Push(temp.right);
                if(temp.left!=null)
                    explore.Push(temp.left);

            }


            return isibst;
        }


    }
}
